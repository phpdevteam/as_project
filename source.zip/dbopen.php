<?php
//Local
$tbname="as";
$projectname = "One Active Space";

$hostname = "localhost";
$database = "devnwzso_as";
$username = "devnwzso_as";
$password = "epnWguZ~T0uM";
$connect = mysql_connect($hostname, $username, $password) or trigger_error(mysql_error(),E_USER_ERROR);

?>
